# From Portland to Portland

### A webpage using CSS, and HTML with the BEM methodology

I have built this webpage using different technologies, such as flexbox nd grid. The webpage is about a coast-to-coast trip of the US. 
I have made a responsive web design and it should look good on all of the most popular screen sizes, therefor I used media queries. For texts I used "Inter" font family. The CSS classes and files were organized according to the BEM methodology.

## Future steps
* Add different fonts in order to make the web page a more personal touch.
* Add further trips such as the USA one, in different parts of the world.